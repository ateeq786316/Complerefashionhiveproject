# Utility functions

This folder contain utility functions that are not used in the
core library, but are useful for building models or training
code using the config system.
